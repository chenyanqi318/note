#include <REGX52.H>

unsigned char code segCode[] = {
    0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07,
    0x7F, 0x6F, 0x77, 0x7C, 0x39, 0x5E, 0x79, 0x71
};

void Delay10ms() {
    unsigned char i, j;
    i = 20;
    j = 113;
    do {
        while (--j);
    } while (--i);
}

unsigned char MatrixKeyScan() {
    unsigned char row, col, key = 0xFF;
    unsigned char code rowCode[4] = {0xFE, 0xFD, 0xFB, 0xF7};

    for (row = 0; row < 4; row++) {
        P1 = rowCode[row];
        col = P1 & 0xF0;
        if (col != 0xF0) {
            Delay10ms();
            P1 = rowCode[row];
            col = P1 & 0xF0;
            if (col != 0xF0) {
                if (col == 0xE0) key = row * 4 + 0;
                if (col == 0xD0) key = row * 4 + 1;
                if (col == 0xB0) key = row * 4 + 2;
                if (col == 0x70) key = row * 4 + 3;
                while ((P1 & 0xF0) != 0xF0);
                Delay10ms();
                return key;
            }
        }
    }
    return 0xFF;
}

void Display(unsigned char num) {
    P2_4 = 1;
    P2_3 = 1;
    P2_2 = 1;
    P0 = segCode[num];
}

void main() {
    unsigned char key;
    Display(0);
    while (1) {
        key = MatrixKeyScan();
        if (key != 0xFF) {
            Display(key);
        }
    }
}