#include <REGX52.H>
unsigned char code segCode[] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F};


void Delay(unsigned int xms) {
    unsigned char i, j;
    while (xms--) {
        i = 2;
        j = 239;
        do {
            while (--j);
        } while (--i);
    }
}

void main() {
    unsigned char i = 0;          
    P2_4 = 1;
    P2_3 = 1;
    P2_2 = 1;
    
    while (1) {
        P0 = 0x00;
        P0 = segCode[i];
        Delay(1000);
        i++;
        if (i == 10) 
					i = 0;
    }
}