#include <REGX52.H>
void Delay1ms(unsigned int xms)		//@12.000MHz
{
	unsigned char i, j;
  while(xms){
		i = 2;
	j = 239;
	do
	{
		while (--j);
	} while (--i);
		xms--;
}
	
}

void main()
{
	 unsigned char tmp=0x80;
	 while(1){ 
		P2=~tmp;
		 Delay1ms(100);
		 tmp >>=1;
		 if(tmp==0x00){
					tmp=0x80;
		 }
}
	 }