#include <REGX51.H>
sbit LED   = P2^0;      
sbit KEY1  = P3^0;      
sbit KEY2  = P3^1;     


void Delay10ms() {
    unsigned char i, j;
    i = 20;
    j = 113;
    do {
        while (--j);
    } while (--i);
}

void main() {
    bit led_state = 0;      
    bit last_key1 = 1;      
    bit last_key2 = 1;      
    
    LED = 1;             
    
    while (1) {
        
        if (KEY1 == 0 && last_key1 == 1) {   
            Delay10ms();                   
            if (KEY1 == 0) {                
                
                led_state = !led_state;
                LED = led_state ? 0 : 1;    
                
                while (KEY1 == 0);
                Delay10ms();                
            }
        }
        last_key1 = KEY1;                 
        
           if (KEY2 == 0 && last_key2 == 1) {
            Delay10ms();
            if (KEY2 == 0) {
                led_state = !led_state;
                LED = led_state ? 0 : 1;
                while (KEY2 == 0);
                Delay10ms();
            }
        }
        last_key2 = KEY2;
    }
}