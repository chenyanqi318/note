#include <REGX52.H>
void main()
{
  P2=0x55;//0XFE
	while(1)
	{
		
	}
}